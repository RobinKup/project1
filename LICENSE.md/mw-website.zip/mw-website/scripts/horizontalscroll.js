
var wrapper = $('.wrapper');

if(wrapper) {


  var wrapperChilds = wrapper.children('');
  var firstChild = wrapperChilds.first();
  var visibleChild = 0;
  var numberOfChilds = wrapperChilds.length;
  
  console.log('BREITE: ' + firstChild.width());

  $('.js-scroll').on('click', function(event) {
    event.preventDefault();
    
    var button = $(this);
    var direction = button.data('direction');
    var newScrollPosition = 0;
    
    if(direction === 'left') {
      visibleChild = (visibleChild > 0) ? visibleChild - 1: 0;
      
      newScrollPosition = (visibleChild * firstChild.width()) + 'px';
    } else if(direction === 'right') {
      visibleChild = (visibleChild < numberOfChilds - 1) ? visibleChild + 1: visibleChild;
      
      newScrollPosition = (visibleChild * firstChild.width()) + 'px';
    }
    
    console.log('visible child', direction, visibleChild, newScrollPosition);

    wrapper.stop().animate({
      scrollLeft: newScrollPosition
    }, function() {
      console.log('ready');
    });





    //console.log('Button wurde geklickt: ' + direction);
  });  
}

